import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import BottomNav from '@/components/nav/BottomNav'

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: profile } = await supabase
    .from('profiles').select('username').eq('id', user.id).single()

  return (
    <div className="min-h-screen bg-bg" style={{ paddingBottom: '60px' }}>
      {children}
      <BottomNav username={profile?.username ?? user.id} />
    </div>
  )
}
